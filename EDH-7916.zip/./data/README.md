# Data

All data you download should go in this folder. I've set up the repo
so that it will not push data files to the remote, except for small
ones that I specifically add. We'll talk about this in class, but the
main reason is that data files can be large and take up unnecessary
space in your repo. The upshot is that you'll have the data on your
machine, but not on GitHub.
